package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.JudgeType;
import com.capstonelegal.judge.service.JudgeTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/judgeTypes")
public class JudgeTypeController {

    @Autowired
    private JudgeTypeService judgeTypeService;

    /**
     * Returns all judgeTypes.
     *
     * @return list of all judgeTypes
     */
    @GetMapping
    public ResponseEntity<List<JudgeType>> getAllJudgeTypes() {
        List<JudgeType> judgeTypes = judgeTypeService.getAllJudgeTypes();
        return new ResponseEntity<>(judgeTypes, HttpStatus.OK);
    }

    /**
     * Returns the judgeType with the specified id.
     *
     * @param id id of the judgeType to return
     * @return judgeType with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<JudgeType> getJudgeTypeById(@PathVariable String id) {
        JudgeType judgeType = judgeTypeService.getJudgeTypeById(id);
        if (judgeType == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(judgeType, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified judgeType.
     *
     * @param judgeType judgeType to create or update
     * @return created or updated judgeType
     */
    @PostMapping
    public ResponseEntity<JudgeType> createOrUpdateJudgeType(@RequestBody JudgeType judgeType) {
        JudgeType createdOrUpdatedJudgeType = judgeTypeService.createOrUpdateJudgeType(judgeType);
        return new ResponseEntity<>(createdOrUpdatedJudgeType, HttpStatus.CREATED);
    }

    /**
     * Deletes the judgeType with the specified id.
     *
     * @param id id of the judgeType to delete
     * @return 204 No Content on success, 404 Not Found if judgeType not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJudgeType(@PathVariable String id) {
        JudgeType judgeType = judgeTypeService.getJudgeTypeById(id);
        if (judgeType == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        judgeTypeService.deleteJudgeType(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
