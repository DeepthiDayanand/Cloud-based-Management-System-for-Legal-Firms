package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.City;
import com.capstonelegal.judge.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cities")
public class CityController {

    @Autowired
    private CityService cityService;

    /**
     * Returns all cities.
     *
     * @return list of all cities
     */
    @GetMapping
    public ResponseEntity<List<City>> getAllCities() {
        List<City> cities = cityService.getAllCitys();
        return new ResponseEntity<>(cities, HttpStatus.OK);
    }

    /**
     * Returns the city with the specified id.
     *
     * @param id id of the city to return
     * @return city with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<City> getCityById(@PathVariable String id) {
        City city = cityService.getCityById(id);
        if (city == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(city, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified city.
     *
     * @param city city to create or update
     * @return created or updated city
     */
    @PostMapping
    public ResponseEntity<City> createOrUpdateCity(@RequestBody City city) {
        City createdOrUpdatedCity = cityService.createOrUpdateCity(city);
        return new ResponseEntity<>(createdOrUpdatedCity, HttpStatus.CREATED);
    }

    /**
     * Deletes the city with the specified id.
     *
     * @param id id of the city to delete
     * @return 204 No Content on success, 404 Not Found if city not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCity(@PathVariable String id) {
        City city = cityService.getCityById(id);
        if (city == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        cityService.deleteCity(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
