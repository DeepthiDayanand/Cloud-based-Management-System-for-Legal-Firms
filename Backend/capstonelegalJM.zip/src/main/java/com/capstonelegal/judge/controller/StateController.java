package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.State;
import com.capstonelegal.judge.service.StateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/states")
public class StateController {

    @Autowired
    private StateService stateService;

    /**
     * Returns all states.
     *
     * @return list of all states
     */
    @GetMapping
    public ResponseEntity<List<State>> getAllStates() {
        List<State> states = stateService.getAllStates();
        return new ResponseEntity<>(states, HttpStatus.OK);
    }

    /**
     * Returns the state with the specified id.
     *
     * @param id id of the state to return
     * @return state with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<State> getStateById(@PathVariable String id) {
        State state = stateService.getStateById(id);
        if (state == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(state, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified state.
     *
     * @param state state to create or update
     * @return created or updated state
     */
    @PostMapping
    public ResponseEntity<State> createOrUpdateState(@RequestBody State state) {
        State createdOrUpdatedState = stateService.createOrUpdateState(state);
        return new ResponseEntity<>(createdOrUpdatedState, HttpStatus.CREATED);
    }

    /**
     * Deletes the state with the specified id.
     *
     * @param id id of the state to delete
     * @return 204 No Content on success, 404 Not Found if state not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteState(@PathVariable String id) {
        State state = stateService.getStateById(id);
        if (state == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        stateService.deleteState(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
