package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.District;
import com.capstonelegal.judge.service.DistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/districts")
public class DistrictController {

    @Autowired
    private DistrictService districtService;

    /**
     * Returns all districts.
     *
     * @return list of all districts
     */
    @GetMapping
    public ResponseEntity<List<District>> getAllDistricts() {
        List<District> districts = districtService.getAllDistricts();
        return new ResponseEntity<>(districts, HttpStatus.OK);
    }

    /**
     * Returns the district with the specified id.
     *
     * @param id id of the district to return
     * @return district with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<District> getDistrictById(@PathVariable String id) {
        District district = districtService.getDistrictById(id);
        if (district == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(district, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified district.
     *
     * @param district district to create or update
     * @return created or updated district
     */
    @PostMapping
    public ResponseEntity<District> createOrUpdateDistrict(@RequestBody District district) {
        District createdOrUpdatedDistrict = districtService.createOrUpdateDistrict(district);
        return new ResponseEntity<>(createdOrUpdatedDistrict, HttpStatus.CREATED);
    }

    /**
     * Deletes the district with the specified id.
     *
     * @param id id of the district to delete
     * @return 204 No Content on success, 404 Not Found if district not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDistrict(@PathVariable String id) {
        District district = districtService.getDistrictById(id);
        if (district == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        districtService.deleteDistrict(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
