package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.Judge;
import com.capstonelegal.judge.service.JudgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/judges")
public class JudgeController {

    @Autowired
    private JudgeService judgeService;

    /**
     * Returns all judges.
     *
     * @return list of all judges
     */
    @GetMapping
    public ResponseEntity<List<Judge>> getAllJudges() {
        List<Judge> judges = judgeService.getAllJudges();
        return new ResponseEntity<>(judges, HttpStatus.OK);
    }

    /**
     * Returns the judge with the specified id.
     *
     * @param id id of the judge to return
     * @return judge with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Judge> getJudgeById(@PathVariable String id) {
        Judge judge = judgeService.getJudgeById(id);
        if (judge == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(judge, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified judge.
     *
     * @param judge judge to create or update
     * @return created or updated judge
     */
    @PostMapping
    public ResponseEntity<Judge> createOrUpdateJudge(@RequestBody Judge judge) {
        Judge createdOrUpdatedJudge = judgeService.createOrUpdateJudge(judge);
        return new ResponseEntity<>(createdOrUpdatedJudge, HttpStatus.CREATED);
    }

    /**
     * Deletes the judge with the specified id.
     *
     * @param id id of the judge to delete
     * @return 204 No Content on success, 404 Not Found if judge not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJudge(@PathVariable String id) {
        Judge judge = judgeService.getJudgeById(id);
        if (judge == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        judgeService.deleteJudge(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
