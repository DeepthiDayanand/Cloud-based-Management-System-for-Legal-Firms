package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.Court;
import com.capstonelegal.judge.service.CourtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courts")
public class CourtController {

    @Autowired
    private CourtService courtService;

    /**
     * Returns all courts.
     *
     * @return list of all courts
     */
    @GetMapping
    public ResponseEntity<List<Court>> getAllCourts() {
        List<Court> courts = courtService.getAllCourts();
        return new ResponseEntity<>(courts, HttpStatus.OK);
    }

    /**
     * Returns the court with the specified id.
     *
     * @param id id of the court to return
     * @return court with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Court> getCourtById(@PathVariable String id) {
        Court court = courtService.getCourtById(id);
        if (court == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(court, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified court.
     *
     * @param court court to create or update
     * @return created or updated court
     */
    @PostMapping
    public ResponseEntity<Court> createOrUpdateCourt(@RequestBody Court court) {
        Court createdOrUpdatedCourt = courtService.createOrUpdateCourt(court);
        return new ResponseEntity<>(createdOrUpdatedCourt, HttpStatus.CREATED);
    }

    /**
     * Deletes the court with the specified id.
     *
     * @param id id of the court to delete
     * @return 204 No Content on success, 404 Not Found if court not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCourt(@PathVariable String id) {
        Court court = courtService.getCourtById(id);
        if (court == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        courtService.deleteCourt(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

