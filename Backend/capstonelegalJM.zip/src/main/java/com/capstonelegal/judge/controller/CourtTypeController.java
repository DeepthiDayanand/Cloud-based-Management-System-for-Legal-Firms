package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.CourtType;
import com.capstonelegal.judge.service.CourtTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courtTypes")
public class CourtTypeController {

    @Autowired
    private CourtTypeService courtTypeService;

    /**
     * Returns all courtTypes.
     *
     * @return list of all courtTypes
     */
    @GetMapping
    public ResponseEntity<List<CourtType>> getAllCourtTypes() {
        List<CourtType> courtTypes = courtTypeService.getAllCourtTypes();
        return new ResponseEntity<>(courtTypes, HttpStatus.OK);
    }

    /**
     * Returns the courtType with the specified id.
     *
     * @param id id of the courtType to return
     * @return courtType with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<CourtType> getCourtTypeById(@PathVariable String id) {
        CourtType courtType = courtTypeService.getCourtTypeById(id);
        if (courtType == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(courtType, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified courtType.
     *
     * @param courtType courtType to create or update
     * @return created or updated courtType
     */
    @PostMapping
    public ResponseEntity<CourtType> createOrUpdateCourtType(@RequestBody CourtType courtType) {
        CourtType createdOrUpdatedCourtType = courtTypeService.createOrUpdateCourtType(courtType);
        return new ResponseEntity<>(createdOrUpdatedCourtType, HttpStatus.CREATED);
    }

    /**
     * Deletes the courtType with the specified id.
     *
     * @param id id of the courtType to delete
     * @return 204 No Content on success, 404 Not Found if courtType not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCourtType(@PathVariable String id) {
        CourtType courtType = courtTypeService.getCourtTypeById(id);
        if (courtType == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        courtTypeService.deleteCourtType(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
