package com.capstonelegal.judge.service;
import com.capstonelegal.judge.model.City;
import com.capstonelegal.judge.repository.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CityService {
    @Autowired
    private CityRepository cityRepository;
    public List<City> getAllCitys() {
        return cityRepository.findAll();
    }

    public City getCityById(String id) {
        return cityRepository.findById(id).orElse(null);
    }

    public City createOrUpdateCity(City city) {
        return cityRepository.save(city);
    }

    public void deleteCity(String id) {
        cityRepository.deleteById(id);
    }
}
