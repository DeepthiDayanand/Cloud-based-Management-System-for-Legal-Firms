package com.capstonelegal.judge.model;

import javax.persistence.*;
import com.google.gson.*;

@Entity
@Table(name = "COURT", schema = "capstonelegalschema")
public class Court {

    @Id
    @Column(name = "COURT_ID", nullable = false)
    private String courtId;

    @ManyToOne
    @JoinColumn(name = "COURT_TYPE_ID", referencedColumnName = "COURT_TYPE_ID")
    private CourtType courtType;

    @Column(name = "COURT_COUNTRY_ID", nullable = false)
    private String courtCountryId;

    @Column(name = "COURT_STATE_ID", nullable = false)
    private String courtStateId;

    @Column(name = "COURT_DISTRICT_ID", nullable = false)
    private String courtDistrictId;

    @Column(name = "COURT_CITY_ID", nullable = false)
    private String courtCityId;

    @Column(name = "COURT_STREET_1", nullable = false)
    private String courtStreet1;


    @Column(name = "COURT_STREET_2")
    private String courtStreet2;

    @Column(name = "COURT_STREET_ZIPCODE")
    private String courtStreetZipcode;

    // getters and setters
    public String getCourtId() {
        return courtId;
    }

    public void setCourtId(String courtId) {
        this.courtId = courtId;
    }

    public CourtType getCourtType() {
        return courtType;
    }

    public void setCourtType(CourtType courtType) {
        this.courtType = courtType;
    }

    public String getCourtCountryId() {
        return courtCountryId;
    }

    public void setCourtCountryId(String courtCountryId) {
        this.courtCountryId = courtCountryId;
    }

    public String getCourtStateId() {
        return courtStateId;
    }

    public void setCourtStateId(String courtStateId) {
        this.courtStateId = courtStateId;
    }

    public String getCourtDistrictId() {
        return courtDistrictId;
    }

    public void setCourtDistrictId(String courtDistrictId){
        this.courtDistrictId = courtDistrictId;
    }
    public String getCourtCityId() {
        return courtCityId;
    }

    public void setCourtCityId(String courtCityId) {
        this.courtCityId = courtCityId;
    }

    public String getCourtStreet1() {
        return courtStreet1;
    }

    public void setCourtStreet1(String courtStreet1) {
        this.courtStreet1 = courtStreet1;
    }

    public String getCourtStreet2() {
        return courtStreet2;
    }

    public void setCourtStreet2(String courtStreet2) {
        this.courtStreet2 = courtStreet2;
    }

    public String getCourtStreetZipcode() {
        return courtStreetZipcode;
    }

    public void setCourtStreetZipcode(String courtStreetZipcode) {
        this.courtStreetZipcode = courtStreetZipcode;
    }
    public String toJSON() {
        return new Gson().toJson(this);
    }
}

