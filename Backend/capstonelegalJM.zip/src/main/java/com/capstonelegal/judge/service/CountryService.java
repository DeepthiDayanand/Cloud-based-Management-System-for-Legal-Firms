package com.capstonelegal.judge.service;
import com.capstonelegal.judge.model.Country;
import com.capstonelegal.judge.repository.CountryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CountryService {
    @Autowired
    private CountryRepository countryRepository;
    public List<Country> getAllCountrys() {
        return countryRepository.findAll();
    }

    public Country getCountryById(String id) {
        return countryRepository.findById(id).orElse(null);
    }

    public Country createOrUpdateCountry(Country country) {
        return countryRepository.save(country);
    }

    public void deleteCountry(String id) {
        countryRepository.deleteById(id);
    }
}
