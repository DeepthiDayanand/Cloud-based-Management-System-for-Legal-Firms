package com.capstonelegal.judge.controller;

import com.capstonelegal.judge.model.Country;
import com.capstonelegal.judge.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/countries")
public class CountryController {

    @Autowired
    private CountryService countryService;

    /**
     * Returns all countries.
     *
     * @return list of all countries
     */
    @GetMapping
    public ResponseEntity<List<Country>> getAllCountries() {
        List<Country> countries = countryService.getAllCountrys();
        return new ResponseEntity<>(countries, HttpStatus.OK);
    }

    /**
     * Returns the country with the specified id.
     *
     * @param id id of the country to return
     * @return country with the specified id or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Country> getCountryById(@PathVariable String id) {
        Country country = countryService.getCountryById(id);
        if (country == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(country, HttpStatus.OK);
    }

    /**
     * Creates or updates the specified country.
     *
     * @param country country to create or update
     * @return created or updated country
     */
    @PostMapping
    public ResponseEntity<Country> createOrUpdateCountry(@RequestBody Country country) {
        Country createdOrUpdatedCountry = countryService.createOrUpdateCountry(country);
        return new ResponseEntity<>(createdOrUpdatedCountry, HttpStatus.CREATED);
    }

    /**
     * Deletes the country with the specified id.
     *
     * @param id id of the country to delete
     * @return 204 No Content on success, 404 Not Found if country not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCountry(@PathVariable String id) {
        Country country = countryService.getCountryById(id);
        if (country == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        countryService.deleteCountry(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
