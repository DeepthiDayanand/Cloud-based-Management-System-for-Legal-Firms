package com.capstonelegal.judge.repository;

import com.capstonelegal.judge.model.Credentials;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface CredentialsRepository  extends JpaRepository<Credentials, String> {
}
