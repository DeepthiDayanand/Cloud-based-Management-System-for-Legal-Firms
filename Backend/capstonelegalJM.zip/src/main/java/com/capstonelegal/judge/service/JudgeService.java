package com.capstonelegal.judge.service;
import com.capstonelegal.judge.model.Judge;
import com.capstonelegal.judge.repository.JudgeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class JudgeService {
    @Autowired
    private JudgeRepository judgeRepository;
    public List<Judge> getAllJudges() {
        return judgeRepository.findAll();
    }

    public Judge getJudgeById(String id) {
        return judgeRepository.findById(id).orElse(null);
    }

    public Judge createOrUpdateJudge(Judge judge) {
        return judgeRepository.save(judge);
    }

    public void deleteJudge(String id) {
        judgeRepository.deleteById(id);
    }
}
