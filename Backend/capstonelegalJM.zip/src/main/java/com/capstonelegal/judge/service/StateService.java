package com.capstonelegal.judge.service;
import com.capstonelegal.judge.model.State;
import com.capstonelegal.judge.repository.StateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StateService {
    @Autowired
    private StateRepository stateRepository;
    public List<State> getAllStates() {
        return stateRepository.findAll();
    }

    public State getStateById(String id) {
        return stateRepository.findById(id).orElse(null);
    }

    public State createOrUpdateState(State state) {
        return stateRepository.save(state);
    }

    public void deleteState(String id) {
        stateRepository.deleteById(id);
    }
}